# CF-StandingFetcher-AIUB
Codeforces Standing Fetcher for Contestants from American International University Bangladesh.<br>
Download The Files and Run index.html
